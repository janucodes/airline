const express = require('express');
const router = express.Router();
const { dbAsync } = require('../db/sqlite');

// Helper to generate a unique readable PNR
function generatePNR() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let pnr = 'SKY';
    for (let i = 0; i < 4; i++) {
        pnr += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return pnr;
}

// POST /api/bookings - Create a new booking
router.post('/', async (req, res) => {
    const { flightId, travelClass, seatNumber, passenger, paymentMethod } = req.body;

    if (!flightId || !travelClass || !seatNumber || !passenger) {
        return res.status(400).json({
            success: false,
            message: 'Missing required booking details (flightId, travelClass, seatNumber, passenger).'
        });
    }

    const { firstName, lastName, email, phone, gender, passportOrId } = passenger;
    if (!firstName || !lastName || !email || !phone) {
        return res.status(400).json({
            success: false,
            message: 'Passenger first name, last name, email, and phone number are required.'
        });
    }

    try {
        // 1. Fetch flight
        const flight = await dbAsync.get('SELECT * FROM flights WHERE flight_id = ?', [flightId]);
        if (!flight) {
            return res.status(404).json({ success: false, message: 'Flight not found.' });
        }

        // 2. Check if seat is already occupied
        const existingSeat = await dbAsync.get(
            'SELECT * FROM seats WHERE flight_id = ? AND seat_number = ? AND is_booked = 1',
            [flightId, seatNumber]
        );

        if (existingSeat) {
            return res.status(409).json({
                success: false,
                message: `Seat ${seatNumber} is already occupied. Please select another seat.`
            });
        }

        // 3. Determine fare based on travel class
        let fare = Number(flight.economy_price);
        if (travelClass === 'Business') fare = Number(flight.business_price);
        else if (travelClass === 'First Class') fare = Number(flight.first_class_price);

        // 4. Insert Passenger
        const passResult = await dbAsync.run(
            `INSERT INTO passengers (first_name, last_name, email, phone, gender, passport_or_id)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [firstName.trim(), lastName.trim(), email.trim().toLowerCase(), phone.trim(), gender || 'Not Specified', passportOrId || 'N/A']
        );
        const passengerId = passResult.lastID;

        // 5. Generate unique PNR
        let pnr = generatePNR();
        let isUnique = false;
        let attempts = 0;
        while (!isUnique && attempts < 5) {
            const check = await dbAsync.get('SELECT booking_id FROM bookings WHERE pnr = ?', [pnr]);
            if (!check) isUnique = true;
            else {
                pnr = generatePNR();
                attempts++;
            }
        }

        // 6. Insert Booking record
        const bookingResult = await dbAsync.run(
            `INSERT INTO bookings 
             (pnr, flight_id, passenger_id, travel_class, seat_number, total_fare, booking_status, payment_status, payment_method)
             VALUES (?, ?, ?, ?, ?, ?, 'CONFIRMED', 'PAID', ?)`,
            [pnr, flightId, passengerId, travelClass, seatNumber, fare, paymentMethod || 'Online Credit Card']
        );
        const bookingId = bookingResult.lastID;

        // 7. Lock the seat in seats table
        await dbAsync.run(
            `INSERT INTO seats (flight_id, seat_number, travel_class, is_booked, booking_id)
             VALUES (?, ?, ?, 1, ?)
             ON CONFLICT(flight_id, seat_number) 
             DO UPDATE SET is_booked = 1, booking_id = excluded.booking_id, travel_class = excluded.travel_class`,
            [flightId, seatNumber, travelClass, bookingId]
        );

        // 8. Fetch complete booking confirmation
        const bookingDetails = await dbAsync.get(
            `SELECT 
                b.booking_id,
                b.pnr,
                b.travel_class,
                b.seat_number,
                b.total_fare,
                b.booking_status,
                b.payment_status,
                b.payment_method,
                b.booking_date,
                p.first_name,
                p.last_name,
                p.email,
                p.phone,
                p.passport_or_id,
                f.flight_number,
                f.airline_name,
                f.origin_code,
                orig.city AS origin_city,
                orig.airport_name AS origin_airport,
                f.destination_code,
                dest.city AS destination_city,
                dest.airport_name AS destination_airport,
                f.departure_time,
                f.arrival_time,
                f.duration,
                f.aircraft_model,
                f.gate,
                f.terminal
            FROM bookings b
            JOIN passengers p ON b.passenger_id = p.passenger_id
            JOIN flights f ON b.flight_id = f.flight_id
            JOIN airports orig ON f.origin_code = orig.airport_code
            JOIN airports dest ON f.destination_code = dest.airport_code
            WHERE b.booking_id = ?`,
            [bookingId]
        );

        res.status(201).json({
            success: true,
            message: 'Booking confirmed successfully in SQLite!',
            booking: bookingDetails
        });

    } catch (err) {
        console.error('Error creating booking in SQLite:', err);
        res.status(500).json({ success: false, message: 'SQLite error: ' + err.message });
    }
});

// GET /api/bookings/:pnr - Retrieve booking by PNR
router.get('/:pnr', async (req, res) => {
    try {
        const pnr = req.params.pnr.trim().toUpperCase();

        const booking = await dbAsync.get(
            `SELECT 
                b.booking_id,
                b.pnr,
                b.travel_class,
                b.seat_number,
                b.total_fare,
                b.booking_status,
                b.payment_status,
                b.payment_method,
                b.booking_date,
                p.first_name,
                p.last_name,
                p.email,
                p.phone,
                p.passport_or_id,
                f.flight_number,
                f.airline_name,
                f.origin_code,
                orig.city AS origin_city,
                orig.airport_name AS origin_airport,
                f.destination_code,
                dest.city AS destination_city,
                dest.airport_name AS destination_airport,
                f.departure_time,
                f.arrival_time,
                f.duration,
                f.aircraft_model,
                f.gate,
                f.terminal
            FROM bookings b
            JOIN passengers p ON b.passenger_id = p.passenger_id
            JOIN flights f ON b.flight_id = f.flight_id
            JOIN airports orig ON f.origin_code = orig.airport_code
            JOIN airports dest ON f.destination_code = dest.airport_code
            WHERE b.pnr = ?`,
            [pnr]
        );

        if (!booking) {
            return res.status(404).json({
                success: false,
                message: `No booking found for PNR reference "${pnr}".`
            });
        }

        res.json({ success: true, booking: booking });
    } catch (err) {
        console.error('Error fetching booking:', err);
        res.status(500).json({ success: false, message: 'SQLite error: ' + err.message });
    }
});

// PUT /api/bookings/:pnr/cancel - Cancel booking & release seat
router.put('/:pnr/cancel', async (req, res) => {
    const pnr = req.params.pnr.trim().toUpperCase();

    try {
        const booking = await dbAsync.get(
            'SELECT booking_id, flight_id, seat_number, booking_status FROM bookings WHERE pnr = ?',
            [pnr]
        );

        if (!booking) {
            return res.status(404).json({ success: false, message: `Booking with PNR "${pnr}" not found.` });
        }

        if (booking.booking_status === 'CANCELLED') {
            return res.status(400).json({ success: false, message: 'This booking is already cancelled.' });
        }

        // Update status
        await dbAsync.run(
            "UPDATE bookings SET booking_status = 'CANCELLED', payment_status = 'REFUNDED' WHERE booking_id = ?",
            [booking.booking_id]
        );

        // Release seat
        await dbAsync.run(
            "UPDATE seats SET is_booked = 0, booking_id = NULL WHERE flight_id = ? AND seat_number = ?",
            [booking.flight_id, booking.seat_number]
        );

        res.json({
            success: true,
            message: `Booking ${pnr} has been successfully cancelled and your seat released.`
        });
    } catch (err) {
        console.error('Error cancelling booking:', err);
        res.status(500).json({ success: false, message: 'SQLite error: ' + err.message });
    }
});

module.exports = router;
