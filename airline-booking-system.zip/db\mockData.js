/**
 * IN-MEMORY MOCK DATA STORE
 * Used automatically as a seamless fallback if local MySQL is temporarily
 * offline or credentials in .env need adjustment.
 */

const mockAirports = [
    { airport_code: 'JFK', city: 'New York', airport_name: 'John F. Kennedy International Airport', country: 'United States' },
    { airport_code: 'LAX', city: 'Los Angeles', airport_name: 'Los Angeles International Airport', country: 'United States' },
    { airport_code: 'LHR', city: 'London', airport_name: 'Heathrow Airport', country: 'United Kingdom' },
    { airport_code: 'DXB', city: 'Dubai', airport_name: 'Dubai International Airport', country: 'United Arab Emirates' },
    { airport_code: 'DEL', city: 'New Delhi', airport_name: 'Indira Gandhi International Airport', country: 'India' },
    { airport_code: 'BOM', city: 'Mumbai', airport_name: 'Chhatrapati Shivaji Maharaj International Airport', country: 'India' },
    { airport_code: 'BLR', city: 'Bengaluru', airport_name: 'Kempegowda International Airport', country: 'India' },
    { airport_code: 'SIN', city: 'Singapore', airport_name: 'Singapore Changi Airport', country: 'Singapore' },
    { airport_code: 'HND', city: 'Tokyo', airport_name: 'Haneda Airport', country: 'Japan' },
    { airport_code: 'SYD', city: 'Sydney', airport_name: 'Sydney Kingsford Smith Airport', country: 'Australia' },
    { airport_code: 'CDG', city: 'Paris', airport_name: 'Charles de Gaulle Airport', country: 'France' },
    { airport_code: 'FRA', city: 'Frankfurt', airport_name: 'Frankfurt Airport', country: 'Germany' }
];

// Helper to generate dynamic mock flights for today and next 14 days
function generateMockFlights() {
    const flights = [];
    let id = 1;

    const baseRoutes = [
        { flight_number: 'AA-101', airline_name: 'American Airways', origin_code: 'JFK', origin_city: 'New York', dest_code: 'LAX', dest_city: 'Los Angeles', depH: 8, depM: 30, arrH: 11, arrM: 45, duration: '5h 15m', eco: 249, bus: 599, first: 1199, aircraft: 'Boeing 787-9 Dreamliner', gate: 'A14', term: 'Terminal 8' },
        { flight_number: 'DL-405', airline_name: 'Delta Airlines', origin_code: 'JFK', origin_city: 'New York', dest_code: 'LAX', dest_city: 'Los Angeles', depH: 16, depM: 0, arrH: 19, arrM: 20, duration: '5h 20m', eco: 279, bus: 649, first: 1249, aircraft: 'Airbus A350-900', gate: 'B22', term: 'Terminal 4' },
        { flight_number: 'AA-102', airline_name: 'American Airways', origin_code: 'LAX', origin_city: 'Los Angeles', dest_code: 'JFK', dest_city: 'New York', depH: 9, depM: 0, arrH: 17, arrM: 30, duration: '5h 30m', eco: 255, bus: 610, first: 1210, aircraft: 'Boeing 787-9 Dreamliner', gate: 'C10', term: 'Terminal 4' },
        { flight_number: 'EK-008', airline_name: 'Emirates', origin_code: 'LHR', origin_city: 'London', dest_code: 'DXB', dest_city: 'Dubai', depH: 14, depM: 20, arrH: 23, arrM: 50, duration: '6h 30m', eco: 520, bus: 1450, first: 2890, aircraft: 'Airbus A380-800', gate: 'G18', term: 'Terminal 3' },
        { flight_number: 'BA-107', airline_name: 'British Airways', origin_code: 'LHR', origin_city: 'London', dest_code: 'DXB', dest_city: 'Dubai', depH: 19, depM: 15, arrH: 5, arrM: 40, duration: '7h 25m', eco: 480, bus: 1390, first: 2750, aircraft: 'Boeing 777-300ER', gate: 'A12', term: 'Terminal 5' },
        { flight_number: 'EK-512', airline_name: 'Emirates', origin_code: 'DXB', origin_city: 'Dubai', dest_code: 'DEL', dest_city: 'New Delhi', depH: 4, depM: 10, arrH: 9, arrM: 5, duration: '3h 25m', eco: 190, bus: 480, first: 890, aircraft: 'Boeing 777-200LR', gate: 'F09', term: 'Terminal 3' },
        { flight_number: 'AI-805', airline_name: 'Air India', origin_code: 'DEL', origin_city: 'New Delhi', dest_code: 'BOM', dest_city: 'Mumbai', depH: 7, depM: 0, arrH: 9, arrM: 15, duration: '2h 15m', eco: 85, bus: 210, first: 420, aircraft: 'Airbus A321neo', gate: 'T14', term: 'Terminal 3' },
        { flight_number: '6E-204', airline_name: 'IndiGo', origin_code: 'DEL', origin_city: 'New Delhi', dest_code: 'BOM', dest_city: 'Mumbai', depH: 18, depM: 45, arrH: 21, arrM: 0, duration: '2h 15m', eco: 75, bus: 180, first: 360, aircraft: 'Airbus A320neo', gate: 'T08', term: 'Terminal 1' },
        { flight_number: 'AI-602', airline_name: 'Air India', origin_code: 'BOM', origin_city: 'Mumbai', dest_code: 'BLR', dest_city: 'Bengaluru', depH: 11, depM: 10, arrH: 13, arrM: 0, duration: '1h 50m', eco: 65, bus: 160, first: 310, aircraft: 'Airbus A320neo', gate: 'B04', term: 'Terminal 2' },
        { flight_number: 'SQ-638', airline_name: 'Singapore Airlines', origin_code: 'SIN', origin_city: 'Singapore', dest_code: 'HND', dest_city: 'Tokyo', depH: 23, depM: 55, arrH: 7, arrM: 30, duration: '6h 35m', eco: 410, bus: 1150, first: 2400, aircraft: 'Boeing 787-10', gate: 'E05', term: 'Terminal 3' },
        { flight_number: 'AF-006', airline_name: 'Air France', origin_code: 'CDG', origin_city: 'Paris', dest_code: 'JFK', dest_city: 'New York', depH: 13, depM: 50, arrH: 16, arrM: 15, duration: '8h 25m', eco: 590, bus: 1620, first: 3200, aircraft: 'Boeing 777-300ER', gate: 'K43', term: 'Terminal 2E' },
        { flight_number: 'LH-778', airline_name: 'Lufthansa', origin_code: 'FRA', origin_city: 'Frankfurt', dest_code: 'SIN', dest_city: 'Singapore', depH: 21, depM: 55, arrH: 16, arrM: 15, duration: '12h 20m', eco: 680, bus: 1890, first: 3600, aircraft: 'Airbus A340-300', gate: 'Z69', term: 'Terminal 1' }
    ];

    const today = new Date();

    for (let dayOffset = 0; dayOffset <= 14; dayOffset++) {
        baseRoutes.forEach(r => {
            const depDate = new Date(today);
            depDate.setDate(today.getDate() + dayOffset);
            depDate.setHours(r.depH, r.depM, 0, 0);

            const arrDate = new Date(depDate);
            arrDate.setHours(r.arrH, r.arrM, 0, 0);
            if (arrDate < depDate) arrDate.setDate(arrDate.getDate() + 1);

            flights.push({
                flight_id: id++,
                flight_number: r.flight_number,
                airline_name: r.airline_name,
                origin_code: r.origin_code,
                origin_city: r.origin_city,
                destination_code: r.dest_code,
                destination_city: r.dest_city,
                departure_time: depDate.toISOString(),
                arrival_time: arrDate.toISOString(),
                duration: r.duration,
                economy_price: r.eco,
                business_price: r.bus,
                first_class_price: r.first,
                aircraft_model: r.aircraft,
                gate: r.gate,
                terminal: r.term,
                total_seats: 60,
                available_seats: 56
            });
        });
    }

    return flights;
}

const mockFlights = generateMockFlights();

// In-memory occupied seats mapping: key `${flightId}_${seatNumber}` -> boolean
const mockOccupiedSeats = new Set(['1_02B', '1_05A', '1_05B', '1_10F']);

// In-memory bookings store
const mockBookings = [
    {
        booking_id: 1,
        pnr: 'SKY-7821',
        flight_id: 1,
        passenger_id: 1,
        first_name: 'John',
        last_name: 'Anderson',
        email: 'john.anderson@example.com',
        phone: '+1-555-0199',
        passport_or_id: 'US987654321',
        travel_class: 'Business',
        seat_number: '02B',
        total_fare: 599.00,
        booking_status: 'CONFIRMED',
        payment_status: 'PAID',
        payment_method: 'Visa ending in 4242',
        booking_date: new Date().toISOString(),
        flight_number: 'AA-101',
        airline_name: 'American Airways',
        origin_code: 'JFK',
        origin_city: 'New York',
        destination_code: 'LAX',
        destination_city: 'Los Angeles',
        departure_time: mockFlights[0].departure_time,
        arrival_time: mockFlights[0].arrival_time,
        duration: '5h 15m',
        aircraft_model: 'Boeing 787-9 Dreamliner',
        gate: 'A14',
        terminal: 'Terminal 8'
    }
];

module.exports = {
    getAirports: () => mockAirports,
    getFlights: () => mockFlights,
    getOccupiedSeats: () => mockOccupiedSeats,
    getBookings: () => mockBookings
};
