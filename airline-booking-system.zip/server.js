const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

// Initialize SQLite database (auto-creates tables and seeds flights)
const { dbAsync, dbPath } = require('./db/sqlite');

const flightRoutes = require('./routes/flights');
const bookingRoutes = require('./routes/bookings');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend files
app.use(express.static(path.join(__dirname, 'public')));

// Health check endpoint
app.get('/api/health', async (req, res) => {
    let dbStatus = 'Connected';
    let flightCount = 0;
    try {
        const result = await dbAsync.get('SELECT COUNT(*) as count FROM flights');
        flightCount = result ? result.count : 0;
    } catch (err) {
        dbStatus = 'Error: ' + err.message;
    }

    res.json({
        status: 'UP',
        timestamp: new Date().toISOString(),
        database: {
            engine: 'SQLite3 (Zero-Config Embedded Database)',
            file: dbPath,
            status: dbStatus,
            totalFlightsLoaded: flightCount
        }
    });
});

// API Routes
app.use('/api/flights', flightRoutes);
app.use('/api/bookings', bookingRoutes);

// Fallback to index.html for SPA routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server
app.listen(PORT, () => {
    console.log('================================================================');
    console.log('✈️   AEROJET AIRWAYS - TICKET BOOKING SYSTEM IS RUNNING');
    console.log('================================================================');
    console.log(`🚀 Web Interface:    http://localhost:${PORT}`);
    console.log(`📊 Health Check:     http://localhost:${PORT}/api/health`);
    console.log(`💾 Database Engine:  SQLite (Embedded local database)`);
    console.log(`📁 Database File:    ${dbPath}`);
    console.log('----------------------------------------------------------------');
    console.log('✨ ZERO SETUP NEEDED! No MySQL Server or credentials required.');
    console.log('================================================================');
});
