# ✈️ AeroJet Airways - Airline Ticket Booking System (SQLite Edition)

A full-stack, zero-configuration Airline Ticket Booking web application built with **Node.js**, **Express**, and **SQLite3**.

> 💡 **Zero Setup Required:** No MySQL Server, no credentials, and no external database setup needed! The application automatically creates and seeds the local database (`db/airline.db`) when started.

---

## 🌟 Key Features

1. **Flight Search & Route Schedule**:
   - Search one-way or round-trip flights across 12 major international hubs.
   - Filter by date, origin, destination, and cabin class (Economy, Business, First Class).
   - Dynamic sorting by price, departure time, and flight duration.

2. **Interactive Aircraft Seat Map**:
   - Visual airplane fuselage layout with Cockpit, Wings, and Cabin dividers.
   - Real-time seat availability check (Available, Selected, Booked).
   - Real-time price updates based on cabin class and seat.

3. **Passenger & Payment Flow**:
   - Passenger details input (Full Name, Email, Phone, Passport / National ID).
   - Simulated card checkout.
   - Atomic database transactions to prevent double-booking.

4. **Digital Boarding Pass / E-Ticket**:
   - Official airline boarding pass design with perforated tear-off stub.
   - Generates unique **PNR (Passenger Name Record)** reference code.
   - Includes Gate, Terminal, Boarding Time, Flight Barcode, and QR Code.
   - One-click **Print / Save as PDF** support (`Ctrl + P` / `Cmd + P` optimized).

5. **Manage Booking & PNR Tracking**:
   - Search booking status anytime using PNR reference (e.g., demo code `SKY-7821`).
   - Retrieve full passenger boarding pass details.
   - Instant reservation cancellation with automatic seat release and refund status update.

---

## 📁 Project Structure

```
airline-booking-system/
├── server.js              # Express application server
├── package.json           # Dependencies (express, sqlite3, dotenv, cors)
├── .env                   # Configuration file
├── run.bat                # 1-click launcher for Windows
├── README.md              # Documentation
├── db/
│   ├── sqlite.js          # SQLite3 database connection & auto-seeding engine
│   └── airline.db         # Auto-generated SQLite database file
├── routes/
│   ├── flights.js         # Flight search & interactive seat map routes
│   └── bookings.js        # Booking creation, PNR lookup & cancellation routes
└── public/                # Frontend Web Interface
    ├── index.html         # User interface & boarding pass layout
    ├── css/style.css      # Aviation styling & print stylesheet
    └── js/app.js          # Client-side controller & seat selection logic
```

---

## 🚀 How to Run in VS Code

### Step 1: Open the Project in VS Code
1. Open **Visual Studio Code**.
2. Go to **File** &rarr; **Open Folder...** (or press `Ctrl + K, Ctrl + O`).
3. Select this folder:
   ```
   C:\Users\Nishanth\.gemini\antigravity\scratch\airline-booking-system
   ```
4. Click **Select Folder**.

---

### Step 2: Start the Application
Open the VS Code Terminal (`Ctrl + ~`) and run:
```bash
npm start
```
*(Alternatively, you can just double-click **`run.bat`** in the project folder!)*

You will see:
```text
================================================================
✈️   AEROJET AIRWAYS - TICKET BOOKING SYSTEM IS RUNNING
================================================================
🚀 Web Interface:    http://localhost:3000
📊 Health Check:     http://localhost:3000/api/health
💾 Database Engine:  SQLite (Embedded local database)
📁 Database File:    .../db/airline.db
----------------------------------------------------------------
✨ ZERO SETUP NEEDED! No MySQL Server or credentials required.
================================================================
```

---

### Step 3: Open in Your Browser
Open Google Chrome, Edge, or Firefox and go to:
👉 **[http://localhost:3000](http://localhost:3000)**

---

## 🧪 Testing the Website

### 1. Booking a Ticket
1. Select **Leaving From** (e.g. `New York (JFK)`) and **Going To** (e.g. `Los Angeles (LAX)`).
2. Choose a **Departure Date** and click **Find Available Flights**.
3. Click **Select Seats** on any flight.
4. Pick an available seat on the airplane fuselage (e.g. `04A` or `07B`).
5. Enter passenger information and click **Pay & Confirm Booking**.
6. Your **Official Electronic Boarding Pass** will be generated with a unique PNR. Click **Print Boarding Pass / PDF** to save or print!

### 2. Testing PNR Lookup & Cancellation
1. In the top navbar, click **Check PNR / Manage Booking**.
2. Enter your generated PNR code or the demo PNR: `SKY-7821`.
3. View real-time reservation status and flight info.
4. Click **Cancel Booking** to test real-time seat release and refund status.

---

## 🔍 How to View the SQLite Database in VS Code (Optional)
If you'd like to inspect the database tables visually inside VS Code:
1. In VS Code, click on the **Extensions** tab (`Ctrl + Shift + X`).
2. Search for **"SQLite Viewer"** (by Florian Klampfer) and click **Install**.
3. Click on the file [`db/airline.db`](file:///C:/Users/Nishanth/.gemini/antigravity/scratch/airline-booking-system/db/airline.db) in the file explorer to view and browse the tables visually!
