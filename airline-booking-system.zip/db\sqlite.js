const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const dbPath = path.resolve(__dirname, 'airline.db');

// Connect to SQLite Database
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('❌ [SQLITE ERROR] Failed to connect to SQLite database:', err.message);
    } else {
        console.log('----------------------------------------------------------------');
        console.log('✅ [SQLITE CONNECTED] Local SQLite Database ready!');
        console.log(`📁 Database File: ${dbPath}`);
        console.log('----------------------------------------------------------------');
    }
});

// Promise wrappers for async/await support
const dbAsync = {
    get: (sql, params = []) => {
        return new Promise((resolve, reject) => {
            db.get(sql, params, (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    },
    all: (sql, params = []) => {
        return new Promise((resolve, reject) => {
            db.all(sql, params, (err, rows) => {
                if (err) reject(err);
                else resolve(rows || []);
            });
        });
    },
    run: (sql, params = []) => {
        return new Promise((resolve, reject) => {
            db.run(sql, params, function (err) {
                if (err) reject(err);
                else resolve({ lastID: this.lastID, changes: this.changes });
            });
        });
    },
    exec: (sql) => {
        return new Promise((resolve, reject) => {
            db.exec(sql, (err) => {
                if (err) reject(err);
                else resolve();
            });
        });
    }
};

// Initialize schema and pre-populate seed data
async function initializeDatabase() {
    try {
        // Enable WAL mode and foreign keys
        await dbAsync.run('PRAGMA foreign_keys = ON;');

        // 1. Airports Table
        await dbAsync.run(`
            CREATE TABLE IF NOT EXISTS airports (
                airport_code TEXT PRIMARY KEY,
                city TEXT NOT NULL,
                airport_name TEXT NOT NULL,
                country TEXT NOT NULL
            );
        `);

        // 2. Flights Table
        await dbAsync.run(`
            CREATE TABLE IF NOT EXISTS flights (
                flight_id INTEGER PRIMARY KEY AUTOINCREMENT,
                flight_number TEXT NOT NULL,
                airline_name TEXT NOT NULL,
                origin_code TEXT NOT NULL,
                destination_code TEXT NOT NULL,
                departure_time TEXT NOT NULL,
                arrival_time TEXT NOT NULL,
                duration TEXT NOT NULL,
                economy_price REAL NOT NULL,
                business_price REAL NOT NULL,
                first_class_price REAL NOT NULL,
                aircraft_model TEXT NOT NULL,
                gate TEXT DEFAULT 'G12',
                terminal TEXT DEFAULT 'T2',
                total_seats INTEGER DEFAULT 60,
                FOREIGN KEY (origin_code) REFERENCES airports(airport_code),
                FOREIGN KEY (destination_code) REFERENCES airports(airport_code)
            );
        `);

        // 3. Passengers Table
        await dbAsync.run(`
            CREATE TABLE IF NOT EXISTS passengers (
                passenger_id INTEGER PRIMARY KEY AUTOINCREMENT,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                email TEXT NOT NULL,
                phone TEXT NOT NULL,
                gender TEXT NOT NULL,
                passport_or_id TEXT NOT NULL,
                created_at TEXT DEFAULT (datetime('now'))
            );
        `);

        // 4. Bookings Table
        await dbAsync.run(`
            CREATE TABLE IF NOT EXISTS bookings (
                booking_id INTEGER PRIMARY KEY AUTOINCREMENT,
                pnr TEXT NOT NULL UNIQUE,
                flight_id INTEGER NOT NULL,
                passenger_id INTEGER NOT NULL,
                travel_class TEXT NOT NULL,
                seat_number TEXT NOT NULL,
                total_fare REAL NOT NULL,
                booking_status TEXT DEFAULT 'CONFIRMED',
                payment_status TEXT DEFAULT 'PAID',
                payment_method TEXT DEFAULT 'Credit Card (Simulated)',
                booking_date TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (flight_id) REFERENCES flights(flight_id),
                FOREIGN KEY (passenger_id) REFERENCES passengers(passenger_id)
            );
        `);

        // 5. Seats Table
        await dbAsync.run(`
            CREATE TABLE IF NOT EXISTS seats (
                seat_id INTEGER PRIMARY KEY AUTOINCREMENT,
                flight_id INTEGER NOT NULL,
                seat_number TEXT NOT NULL,
                travel_class TEXT NOT NULL,
                is_booked INTEGER DEFAULT 0,
                booking_id INTEGER,
                FOREIGN KEY (flight_id) REFERENCES flights(flight_id),
                FOREIGN KEY (booking_id) REFERENCES bookings(booking_id),
                UNIQUE(flight_id, seat_number)
            );
        `);

        // Check if airports are already populated
        const airportCount = await dbAsync.get('SELECT COUNT(*) as count FROM airports');
        if (airportCount.count === 0) {
            console.log('🌱 [SQLITE SEEDING] Populating initial airports and flights...');

            // Seed Airports
            const airports = [
                ['JFK', 'New York', 'John F. Kennedy International Airport', 'United States'],
                ['LAX', 'Los Angeles', 'Los Angeles International Airport', 'United States'],
                ['LHR', 'London', 'Heathrow Airport', 'United Kingdom'],
                ['DXB', 'Dubai', 'Dubai International Airport', 'United Arab Emirates'],
                ['DEL', 'New Delhi', 'Indira Gandhi International Airport', 'India'],
                ['BOM', 'Mumbai', 'Chhatrapati Shivaji Maharaj International Airport', 'India'],
                ['BLR', 'Bengaluru', 'Kempegowda International Airport', 'India'],
                ['SIN', 'Singapore', 'Singapore Changi Airport', 'Singapore'],
                ['HND', 'Tokyo', 'Haneda Airport', 'Japan'],
                ['SYD', 'Sydney', 'Sydney Kingsford Smith Airport', 'Australia'],
                ['CDG', 'Paris', 'Charles de Gaulle Airport', 'France'],
                ['FRA', 'Frankfurt', 'Frankfurt Airport', 'Germany']
            ];

            for (const [code, city, name, country] of airports) {
                await dbAsync.run(
                    'INSERT OR IGNORE INTO airports (airport_code, city, airport_name, country) VALUES (?, ?, ?, ?)',
                    [code, city, name, country]
                );
            }

            // Seed dynamic flights across next 14 days
            const flightTemplates = [
                { num: 'AA-101', airline: 'American Airways', orig: 'JFK', dest: 'LAX', depH: 8, depM: 30, arrH: 11, arrM: 45, dur: '5h 15m', eco: 249, bus: 599, first: 1199, craft: 'Boeing 787-9 Dreamliner', gate: 'A14', term: 'Terminal 8' },
                { num: 'DL-405', airline: 'Delta Airlines', orig: 'JFK', dest: 'LAX', depH: 16, depM: 0, arrH: 19, arrM: 20, dur: '5h 20m', eco: 279, bus: 649, first: 1249, craft: 'Airbus A350-900', gate: 'B22', term: 'Terminal 4' },
                { num: 'AA-102', airline: 'American Airways', orig: 'LAX', dest: 'JFK', depH: 9, depM: 0, arrH: 17, arrM: 30, dur: '5h 30m', eco: 255, bus: 610, first: 1210, craft: 'Boeing 787-9 Dreamliner', gate: 'C10', term: 'Terminal 4' },
                { num: 'EK-008', airline: 'Emirates', orig: 'LHR', dest: 'DXB', depH: 14, depM: 20, arrH: 23, arrM: 50, dur: '6h 30m', eco: 520, bus: 1450, first: 2890, craft: 'Airbus A380-800', gate: 'G18', term: 'Terminal 3' },
                { num: 'BA-107', airline: 'British Airways', orig: 'LHR', dest: 'DXB', depH: 19, depM: 15, arrH: 5, arrM: 40, dur: '7h 25m', eco: 480, bus: 1390, first: 2750, craft: 'Boeing 777-300ER', gate: 'A12', term: 'Terminal 5' },
                { num: 'EK-512', airline: 'Emirates', orig: 'DXB', dest: 'DEL', depH: 4, depM: 10, arrH: 9, arrM: 5, dur: '3h 25m', eco: 190, bus: 480, first: 890, craft: 'Boeing 777-200LR', gate: 'F09', term: 'Terminal 3' },
                { num: 'AI-805', airline: 'Air India', orig: 'DEL', dest: 'BOM', depH: 7, depM: 0, arrH: 9, arrM: 15, dur: '2h 15m', eco: 85, bus: 210, first: 420, craft: 'Airbus A321neo', gate: 'T14', term: 'Terminal 3' },
                { num: '6E-204', airline: 'IndiGo', orig: 'DEL', dest: 'BOM', depH: 18, depM: 45, arrH: 21, arrM: 0, dur: '2h 15m', eco: 75, bus: 180, first: 360, craft: 'Airbus A320neo', gate: 'T08', term: 'Terminal 1' },
                { num: 'AI-602', airline: 'Air India', orig: 'BOM', dest: 'BLR', depH: 11, depM: 10, arrH: 13, arrM: 0, dur: '1h 50m', eco: 65, bus: 160, first: 310, craft: 'Airbus A320neo', gate: 'B04', term: 'Terminal 2' },
                { num: 'SQ-638', airline: 'Singapore Airlines', orig: 'SIN', dest: 'HND', depH: 23, depM: 55, arrH: 7, arrM: 30, dur: '6h 35m', eco: 410, bus: 1150, first: 2400, craft: 'Boeing 787-10', gate: 'E05', term: 'Terminal 3' },
                { num: 'AF-006', airline: 'Air France', orig: 'CDG', dest: 'JFK', depH: 13, depM: 50, arrH: 16, arrM: 15, dur: '8h 25m', eco: 590, bus: 1620, first: 3200, craft: 'Boeing 777-300ER', gate: 'K43', term: 'Terminal 2E' },
                { num: 'LH-778', airline: 'Lufthansa', orig: 'FRA', dest: 'SIN', depH: 21, depM: 55, arrH: 16, arrM: 15, dur: '12h 20m', eco: 680, bus: 1890, first: 3600, craft: 'Airbus A340-300', gate: 'Z69', term: 'Terminal 1' }
            ];

            const today = new Date();

            for (let dayOffset = 0; dayOffset <= 14; dayOffset++) {
                for (const t of flightTemplates) {
                    const depDate = new Date(today);
                    depDate.setDate(today.getDate() + dayOffset);
                    depDate.setHours(t.depH, t.depM, 0, 0);

                    const arrDate = new Date(depDate);
                    arrDate.setHours(t.arrH, t.arrM, 0, 0);
                    if (arrDate < depDate) arrDate.setDate(arrDate.getDate() + 1);

                    const depIso = depDate.toISOString().replace('T', ' ').substring(0, 19);
                    const arrIso = arrDate.toISOString().replace('T', ' ').substring(0, 19);

                    await dbAsync.run(`
                        INSERT INTO flights 
                        (flight_number, airline_name, origin_code, destination_code, departure_time, arrival_time, duration, economy_price, business_price, first_class_price, aircraft_model, gate, terminal, total_seats)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 60)
                    `, [t.num, t.airline, t.orig, t.dest, depIso, arrIso, t.dur, t.eco, t.bus, t.first, t.craft, t.gate, t.term]);
                }
            }

            // Seed sample Passenger & Booking
            const passResult = await dbAsync.run(`
                INSERT INTO passengers (first_name, last_name, email, phone, gender, passport_or_id)
                VALUES ('John', 'Anderson', 'john.anderson@example.com', '+1-555-0199', 'Male', 'US987654321')
            `);

            await dbAsync.run(`
                INSERT INTO bookings (pnr, flight_id, passenger_id, travel_class, seat_number, total_fare, booking_status, payment_status, payment_method)
                VALUES ('SKY-7821', 1, ?, 'Business', '02B', 599.00, 'CONFIRMED', 'PAID', 'Visa ending in 4242')
            `, [passResult.lastID]);

            // Seed sample occupied seats for flight 1
            await dbAsync.run(`INSERT INTO seats (flight_id, seat_number, travel_class, is_booked, booking_id) VALUES (1, '02B', 'Business', 1, 1)`);
            await dbAsync.run(`INSERT INTO seats (flight_id, seat_number, travel_class, is_booked, booking_id) VALUES (1, '05A', 'Economy', 1, NULL)`);
            await dbAsync.run(`INSERT INTO seats (flight_id, seat_number, travel_class, is_booked, booking_id) VALUES (1, '05B', 'Economy', 1, NULL)`);
            await dbAsync.run(`INSERT INTO seats (flight_id, seat_number, travel_class, is_booked, booking_id) VALUES (1, '10F', 'Economy', 1, NULL)`);

            console.log('✅ [SQLITE SEEDING] Initial database setup completed successfully!');
        }
    } catch (err) {
        console.error('❌ [SQLITE INIT ERROR]:', err.message);
    }
}

initializeDatabase();

module.exports = {
    db,
    dbAsync,
    dbPath
};
