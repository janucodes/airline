const mysql = require('mysql2/promise');
require('dotenv').config();

const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'airline_db',
    port: Number(process.env.DB_PORT) || 3306,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 0
};

// Create MySQL connection pool
const pool = mysql.createPool(dbConfig);

let isDbConnected = false;
let lastDbError = null;

async function testConnection() {
    try {
        const connection = await pool.getConnection();
        isDbConnected = true;
        lastDbError = null;
        console.log('----------------------------------------------------------------');
        console.log(`✅ [DATABASE CONNECTED] Successfully connected to MySQL server!`);
        console.log(`   Database : ${dbConfig.database}`);
        console.log(`   Host     : ${dbConfig.host}:${dbConfig.port}`);
        console.log(`   User     : ${dbConfig.user}`);
        console.log('----------------------------------------------------------------');
        connection.release();
        return true;
    } catch (err) {
        isDbConnected = false;
        lastDbError = err;
        console.log('----------------------------------------------------------------');
        console.error('❌ [DATABASE CONNECTION FAILED]');
        console.error(`   Host:     ${dbConfig.host}:${dbConfig.port}`);
        console.error(`   User:     ${dbConfig.user}`);
        console.error(`   Password: ${dbConfig.password ? '****** (configured)' : '(empty)'}`);
        console.error(`   Error:    ${err.code || 'UNKNOWN'} - ${err.message}`);
        console.log('');
        console.log('🔍 HOW TO FIX THIS:');

        if (err.code === 'ECONNREFUSED') {
            console.log('   👉 1. MySQL Server is NOT running on your computer.');
            console.log('      • Press Win + R, type "services.msc" and press Enter.');
            console.log('      • Scroll down to "MySQL80" (or "MySQL"), right-click it, and select "Start".');
            console.log('      • Alternatively, open MySQL Workbench and start the Local Server from the left sidebar.');
        } else if (err.code === 'ER_ACCESS_DENIED_ERROR') {
            console.log('   👉 2. MySQL password in your .env file is incorrect.');
            console.log('      • Open ".env" in VS Code.');
            console.log('      • Update DB_PASSWORD=your_actual_password (the password you use to log into MySQL Workbench).');
        } else if (err.code === 'ER_BAD_DB_ERROR') {
            console.log('   👉 3. Database "airline_db" does not exist yet.');
            console.log('      • Open MySQL Workbench.');
            console.log('      • Open file "db/schema.sql" and click the yellow lightning bolt icon ⚡ to execute it.');
        } else {
            console.log('   👉 Make sure MySQL Server is running, credentials in .env are correct, and schema.sql has been executed.');
        }

        console.log('');
        console.log('⚡ NOTE: The website has automatically activated In-Memory Demo Mode!');
        console.log('   You can still search flights, select seats, book tickets, and print boarding passes.');
        console.log('----------------------------------------------------------------');
        return false;
    }
}

// Initial connection test
testConnection();

module.exports = {
    pool,
    isDbConnected: () => isDbConnected,
    getLastDbError: () => lastDbError,
    reconnect: testConnection
};
