const express = require('express');
const router = express.Router();
const { dbAsync } = require('../db/sqlite');

// GET /api/flights/airports - Fetch all supported airports
router.get('/airports', async (req, res) => {
    try {
        const rows = await dbAsync.all(
            'SELECT airport_code, city, airport_name, country FROM airports ORDER BY city ASC'
        );
        res.json({ success: true, count: rows.length, data: rows });
    } catch (err) {
        console.error('Error fetching airports:', err);
        res.status(500).json({ success: false, message: 'SQLite error: ' + err.message });
    }
});

// GET /api/flights - Search flights based on origin, destination, and optional date
router.get('/', async (req, res) => {
    try {
        const { origin, destination, date, travelClass = 'Economy' } = req.query;

        let sql = `
            SELECT 
                f.flight_id,
                f.flight_number,
                f.airline_name,
                f.origin_code,
                orig.city AS origin_city,
                orig.airport_name AS origin_airport,
                f.destination_code,
                dest.city AS destination_city,
                dest.airport_name AS destination_airport,
                f.departure_time,
                f.arrival_time,
                f.duration,
                f.economy_price,
                f.business_price,
                f.first_class_price,
                f.aircraft_model,
                f.gate,
                f.terminal,
                f.total_seats,
                (f.total_seats - (
                    SELECT COUNT(*) FROM seats s WHERE s.flight_id = f.flight_id AND s.is_booked = 1
                )) AS available_seats
            FROM flights f
            JOIN airports orig ON f.origin_code = orig.airport_code
            JOIN airports dest ON f.destination_code = dest.airport_code
            WHERE 1=1
        `;

        const params = [];

        if (origin) {
            sql += ` AND f.origin_code = ?`;
            params.push(origin.toUpperCase());
        }

        if (destination) {
            sql += ` AND f.destination_code = ?`;
            params.push(destination.toUpperCase());
        }

        if (date) {
            // SQLite date matching: substr(f.departure_time, 1, 10) or date(...)
            sql += ` AND date(f.departure_time) = date(?)`;
            params.push(date);
        }

        sql += ` ORDER BY f.departure_time ASC`;

        const rows = await dbAsync.all(sql, params);

        // Find alternatives on that route if exact date has no results
        let alternativeFlights = [];
        if (rows.length === 0 && origin && destination) {
            alternativeFlights = await dbAsync.all(`
                SELECT 
                    f.flight_id,
                    f.flight_number,
                    f.airline_name,
                    f.origin_code,
                    orig.city AS origin_city,
                    f.destination_code,
                    dest.city AS destination_city,
                    f.departure_time,
                    f.arrival_time,
                    f.duration,
                    f.economy_price,
                    f.business_price,
                    f.first_class_price,
                    f.aircraft_model,
                    f.gate,
                    f.terminal
                FROM flights f
                JOIN airports orig ON f.origin_code = orig.airport_code
                JOIN airports dest ON f.destination_code = dest.airport_code
                WHERE f.origin_code = ? AND f.destination_code = ?
                ORDER BY f.departure_time ASC
                LIMIT 5
            `, [origin.toUpperCase(), destination.toUpperCase()]);
        }

        res.json({
            success: true,
            count: rows.length,
            data: rows,
            alternatives: alternativeFlights
        });
    } catch (err) {
        console.error('Error searching flights:', err);
        res.status(500).json({ success: false, message: 'SQLite error: ' + err.message });
    }
});

// GET /api/flights/:id/seats - Get interactive seat layout & availability
router.get('/:id/seats', async (req, res) => {
    try {
        const flightId = Number(req.params.id);

        const flight = await dbAsync.get('SELECT flight_id, flight_number FROM flights WHERE flight_id = ?', [flightId]);
        if (!flight) {
            return res.status(404).json({ success: false, message: 'Flight not found' });
        }

        const bookedRows = await dbAsync.all(
            'SELECT seat_number, travel_class FROM seats WHERE flight_id = ? AND is_booked = 1',
            [flightId]
        );

        const bookedSeatSet = new Set(bookedRows.map(s => s.seat_number));

        // Generate 60 seats (15 Rows x 4 Columns: A, B [aisle] C, D)
        const seatMap = [];
        const cols = ['A', 'B', 'C', 'D'];

        for (let row = 1; row <= 15; row++) {
            const rowNumber = row < 10 ? `0${row}` : `${row}`;
            let travelClass = 'Economy';
            if (row <= 2) travelClass = 'First Class';
            else if (row <= 5) travelClass = 'Business';

            for (const col of cols) {
                const seatCode = `${rowNumber}${col}`;
                seatMap.push({
                    seatNumber: seatCode,
                    row: row,
                    column: col,
                    travelClass: travelClass,
                    isBooked: bookedSeatSet.has(seatCode)
                });
            }
        }

        res.json({
            success: true,
            flightId: flightId,
            flightNumber: flight.flight_number,
            totalSeats: seatMap.length,
            occupiedSeatsCount: bookedSeatSet.size,
            availableSeatsCount: seatMap.length - bookedSeatSet.size,
            seatMap: seatMap
        });
    } catch (err) {
        console.error('Error fetching seats:', err);
        res.status(500).json({ success: false, message: 'SQLite error: ' + err.message });
    }
});

module.exports = router;
