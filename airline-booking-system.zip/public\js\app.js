/**
 * AEROJET AIRWAYS - FRONTEND CONTROLLER
 * Handles flight search, interactive seat selection, booking creation,
 * boarding pass generation, and PNR management.
 */

// Global Application State
const state = {
    airports: [],
    searchResults: [],
    selectedFlight: null,
    selectedClass: 'Economy',
    selectedSeat: null,
    selectedFare: 0,
    currentBooking: null
};

// Initialize Application on DOM Ready
document.addEventListener('DOMContentLoaded', () => {
    initDateInput();
    checkDatabaseHealth();
    loadAirports();
    setupEventListeners();
});

// 1. Initialize Date Input to Default to Tomorrow
function initDateInput() {
    const dateInput = document.getElementById('departureDate');
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const formatDate = (d) => d.toISOString().split('T')[0];
    dateInput.min = formatDate(today);
    dateInput.value = formatDate(tomorrow);
}

// 2. Check Backend & SQLite Database Health
async function checkDatabaseHealth() {
    const badge = document.getElementById('dbStatusBadge');
    const banner = document.getElementById('dbNoticeBanner');

    try {
        const res = await fetch('/api/health');
        const data = await res.json();

        if (data.database && data.database.status === 'Connected') {
            badge.className = 'status-badge connected';
            badge.querySelector('.status-text').textContent = 'SQLite Connected';
            badge.title = `SQLite active with ${data.database.totalFlightsLoaded} flights ready!`;
            if (banner) banner.classList.add('hidden');
        } else {
            throw new Error(data.database ? data.database.status : 'DB not ready');
        }
    } catch (err) {
        badge.className = 'status-badge disconnected';
        badge.querySelector('.status-text').textContent = 'Database Offline';
        badge.title = 'Database not connected. Please restart server.';
        if (banner) banner.classList.remove('hidden');
    }
}

// 3. Load Supported Airports from Database
async function loadAirports() {
    try {
        const res = await fetch('/api/flights/airports');
        const json = await res.json();

        if (json.success && json.data.length > 0) {
            state.airports = json.data;
            populateAirportSelect('originSelect', json.data);
            populateAirportSelect('destinationSelect', json.data);

            // Default selections
            document.getElementById('originSelect').value = 'JFK';
            document.getElementById('destinationSelect').value = 'LAX';
        }
    } catch (err) {
        console.warn('Could not load dynamic airports, using fallback list.');
    }
}

function populateAirportSelect(selectId, airports) {
    const select = document.getElementById(selectId);
    select.innerHTML = '<option value="" disabled selected>Select City / Airport</option>';

    airports.forEach(ap => {
        const opt = document.createElement('option');
        opt.value = ap.airport_code;
        opt.textContent = `${ap.city} (${ap.airport_code}) - ${ap.country}`;
        select.appendChild(opt);
    });
}

// 4. Setup Event Listeners
function setupEventListeners() {
    // Swap Origin and Destination
    document.getElementById('swapLocationsBtn').addEventListener('click', () => {
        const orig = document.getElementById('originSelect');
        const dest = document.getElementById('destinationSelect');
        const temp = orig.value;
        orig.value = dest.value;
        dest.value = temp;
    });

    // Flight Search Form Submission
    document.getElementById('flightSearchForm').addEventListener('submit', handleFlightSearch);

    // Passenger Form Submission
    document.getElementById('passengerBookingForm').addEventListener('submit', handleBookingSubmit);

    // Trip type tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            e.currentTarget.classList.add('active');
        });
    });
}

// Quick Search from Popular Destination Cards
function quickSearch(origin, destination) {
    document.getElementById('originSelect').value = origin;
    document.getElementById('destinationSelect').value = destination;
    document.getElementById('search-section').scrollIntoView({ behavior: 'smooth' });
    handleFlightSearch(new Event('submit'));
}

// 5. Handle Flight Search
async function handleFlightSearch(e) {
    if (e && e.preventDefault) e.preventDefault();

    const origin = document.getElementById('originSelect').value;
    const destination = document.getElementById('destinationSelect').value;
    const date = document.getElementById('departureDate').value;
    const travelClass = document.getElementById('travelClassSelect').value;

    if (!origin || !destination) {
        alert('Please select both Origin and Destination airports.');
        return;
    }

    if (origin === destination) {
        alert('Origin and Destination cannot be the same airport!');
        return;
    }

    state.selectedClass = travelClass;

    const btn = document.getElementById('searchSubmitBtn');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Searching Flights...';
    btn.disabled = true;

    try {
        const res = await fetch(`/api/flights?origin=${origin}&destination=${destination}&date=${date}&travelClass=${travelClass}`);
        const data = await res.json();

        const resultsSection = document.getElementById('resultsSection');
        const flightsContainer = document.getElementById('flightsContainer');
        resultsSection.classList.remove('hidden');

        if (data.success && (data.data.length > 0 || (data.alternatives && data.alternatives.length > 0))) {
            const flightsToRender = data.data.length > 0 ? data.data : data.alternatives;
            state.searchResults = flightsToRender;

            document.getElementById('resultsHeading').textContent = `Available Flights (${origin} → ${destination})`;
            document.getElementById('resultsSubheading').textContent = data.data.length > 0 
                ? `Found ${data.data.length} scheduled flights for your selected date`
                : `No flights on exact date, showing available flights on closest upcoming dates on this route`;

            renderFlightCards(flightsToRender);
            resultsSection.scrollIntoView({ behavior: 'smooth' });
        } else {
            flightsContainer.innerHTML = `
                <div class="search-widget-card text-center" style="padding: 40px;">
                    <i class="fa-solid fa-plane-slash" style="font-size: 48px; color: #94a3b8; margin-bottom: 16px;"></i>
                    <h3>No Flights Found For This Route</h3>
                    <p class="text-muted">No scheduled flights between ${origin} and ${destination}. Try popular routes like JFK &rarr; LAX or LHR &rarr; DXB.</p>
                </div>
            `;
            resultsSection.scrollIntoView({ behavior: 'smooth' });
        }
    } catch (err) {
        console.error('Search error:', err);
        alert('Error searching flights: ' + err.message + '\nPlease verify your MySQL database is running.');
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}

// 6. Render Flight Result Cards
function renderFlightCards(flights) {
    const container = document.getElementById('flightsContainer');
    container.innerHTML = '';

    flights.forEach(f => {
        const depTime = new Date(f.departure_time);
        const arrTime = new Date(f.arrival_time);

        const formatTime = (d) => d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const formatDate = (d) => d.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });

        // Calculate active class fare
        let fare = f.economy_price;
        if (state.selectedClass === 'Business') fare = f.business_price;
        if (state.selectedClass === 'First Class') fare = f.first_class_price;

        const card = document.createElement('div');
        card.className = 'flight-card';
        card.innerHTML = `
            <div class="flight-brand">
                <div class="flight-logo-icon">
                    <i class="fa-solid fa-plane-departure"></i>
                </div>
                <div class="flight-brand-info">
                    <h4>${f.airline_name}</h4>
                    <span class="flight-code">${f.flight_number}</span> &bull; 
                    <span class="flight-aircraft">${f.aircraft_model || 'Boeing 787'}</span>
                </div>
            </div>

            <div class="flight-timeline">
                <div class="time-box">
                    <h3>${formatTime(depTime)}</h3>
                    <div class="airport-code">${f.origin_code}</div>
                    <div class="airport-city">${f.origin_city || ''}</div>
                    <small class="text-muted">${formatDate(depTime)}</small>
                </div>

                <div class="timeline-track">
                    <div class="duration-tag"><i class="fa-regular fa-clock"></i> ${f.duration}</div>
                    <div class="track-line">
                        <i class="fa-solid fa-plane"></i>
                    </div>
                    <div class="direct-tag">Non-Stop</div>
                </div>

                <div class="time-box text-right">
                    <h3>${formatTime(arrTime)}</h3>
                    <div class="airport-code">${f.destination_code}</div>
                    <div class="airport-city">${f.destination_city || ''}</div>
                    <small class="text-muted">${formatDate(arrTime)}</small>
                </div>
            </div>

            <div class="flight-pricing-cta">
                <div class="price-display">
                    <div class="price-label">Price per passenger</div>
                    <div class="price-amount">$${Number(fare).toFixed(2)}</div>
                    <span class="class-pill">${state.selectedClass} Class</span>
                </div>
                <button class="btn btn-primary" onclick="initiateSeatSelection(${f.flight_id})">
                    Select Seats &rarr;
                </button>
            </div>
        `;
        container.appendChild(card);
    });
}

// 7. Initiate Interactive Seat Selection Modal
async function initiateSeatSelection(flightId) {
    const flight = state.searchResults.find(f => f.flight_id === flightId);
    if (!flight) return;

    state.selectedFlight = flight;
    state.selectedSeat = null;

    // Determine current fare
    let fare = Number(flight.economy_price);
    if (state.selectedClass === 'Business') fare = Number(flight.business_price);
    if (state.selectedClass === 'First Class') fare = Number(flight.first_class_price);
    state.selectedFare = fare;

    // Update modal header info
    document.getElementById('seatModalFlightInfo').textContent = 
        `Flight ${flight.flight_number} (${flight.airline_name}) • ${flight.origin_code} to ${flight.destination_code}`;
    document.getElementById('selectedClassBadge').textContent = state.selectedClass;
    document.getElementById('selectedSeatBadge').textContent = 'None Selected';
    document.getElementById('selectedFareBadge').textContent = `$${fare.toFixed(2)}`;
    document.getElementById('btnProceedToPassenger').disabled = true;

    // Load seats from backend
    const grid = document.getElementById('seatGrid');
    grid.innerHTML = '<div class="text-center p-4"><i class="fa-solid fa-spinner fa-spin"></i> Loading aircraft seat map...</div>';

    openModal('seatModal');

    try {
        const res = await fetch(`/api/flights/${flightId}/seats`);
        const data = await res.json();

        if (data.success) {
            renderAirplaneSeats(data.seatMap);
        } else {
            throw new Error(data.message);
        }
    } catch (err) {
        console.error('Seat map load error:', err);
        grid.innerHTML = `<div class="text-danger p-4">Error loading seat layout: ${err.message}</div>`;
    }
}

// 8. Render Fuselage Seat Map
function renderAirplaneSeats(seats) {
    const grid = document.getElementById('seatGrid');
    grid.innerHTML = '';

    // Group seats by row number
    const rowsMap = {};
    seats.forEach(s => {
        if (!rowsMap[s.row]) rowsMap[s.row] = [];
        rowsMap[s.row].push(s);
    });

    let currentCabin = '';

    Object.keys(rowsMap).forEach(rowNum => {
        const rowSeats = rowsMap[rowNum];
        const travelClass = rowSeats[0].travelClass;

        // Add section label between cabins
        if (travelClass !== currentCabin) {
            currentCabin = travelClass;
            const divider = document.createElement('div');
            divider.className = 'cabin-divider';
            divider.textContent = `${currentCabin} Cabin`;
            grid.appendChild(divider);
        }

        const rowDiv = document.createElement('div');
        rowDiv.className = 'seat-row';

        // Left seats (A, B)
        const leftGroup = document.createElement('div');
        leftGroup.className = 'seat-group';
        const leftSeats = rowSeats.filter(s => s.column === 'A' || s.column === 'B');
        leftSeats.forEach(s => leftGroup.appendChild(createSeatButton(s)));

        // Aisle indicator with row number
        const aisleDiv = document.createElement('div');
        aisleDiv.className = 'seat-aisle';
        aisleDiv.textContent = rowNum;

        // Right seats (C, D)
        const rightGroup = document.createElement('div');
        rightGroup.className = 'seat-group';
        const rightSeats = rowSeats.filter(s => s.column === 'C' || s.column === 'D');
        rightSeats.forEach(s => rightGroup.appendChild(createSeatButton(s)));

        rowDiv.appendChild(leftGroup);
        rowDiv.appendChild(aisleDiv);
        rowDiv.appendChild(rightGroup);

        grid.appendChild(rowDiv);
    });
}

function createSeatButton(seat) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `seat-btn ${seat.isBooked ? 'occupied' : 'available'}`;
    btn.textContent = seat.seatNumber;
    btn.disabled = seat.isBooked;
    btn.title = seat.isBooked ? `Seat ${seat.seatNumber} (Occupied)` : `Seat ${seat.seatNumber} (${seat.travelClass})`;

    btn.addEventListener('click', () => {
        // Remove active class from previous seat
        document.querySelectorAll('.seat-btn.selected').forEach(b => b.classList.remove('selected'));

        // Select new seat
        btn.classList.add('selected');
        state.selectedSeat = seat.seatNumber;
        state.selectedClass = seat.travelClass;

        // Recalculate price if cabin differs
        let fare = Number(state.selectedFlight.economy_price);
        if (seat.travelClass === 'Business') fare = Number(state.selectedFlight.business_price);
        if (seat.travelClass === 'First Class') fare = Number(state.selectedFlight.first_class_price);
        state.selectedFare = fare;

        document.getElementById('selectedSeatBadge').textContent = seat.seatNumber;
        document.getElementById('selectedClassBadge').textContent = seat.travelClass;
        document.getElementById('selectedFareBadge').textContent = `$${fare.toFixed(2)}`;
        document.getElementById('btnProceedToPassenger').disabled = false;
    });

    return btn;
}

// 9. Open Passenger & Payment Modal
function openPassengerModal() {
    closeModal('seatModal');

    const f = state.selectedFlight;
    const depTime = new Date(f.departure_time);

    // Populate mini trip summary
    document.getElementById('passengerFlightSummary').innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <strong>${f.airline_name} (${f.flight_number})</strong>: ${f.origin_code} &rarr; ${f.destination_code}
                <div style="font-size: 12px; color: #64748b;">${depTime.toDateString()} at ${depTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
            </div>
            <div style="text-align: right;">
                <div>Seat: <strong>${state.selectedSeat}</strong> (${state.selectedClass})</div>
                <div style="font-size: 16px; font-weight: 800; color: #10b981;">Total: $${state.selectedFare.toFixed(2)}</div>
            </div>
        </div>
    `;

    document.getElementById('btnConfirmPay').innerHTML = 
        `<i class="fa-solid fa-lock"></i> Pay $${state.selectedFare.toFixed(2)} & Confirm`;

    openModal('passengerModal');
}

// 10. Handle Booking Submission (POST /api/bookings)
async function handleBookingSubmit(e) {
    e.preventDefault();

    const btn = document.getElementById('btnConfirmPay');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing Payment & Reserving Seat...';
    btn.disabled = true;

    const payload = {
        flightId: state.selectedFlight.flight_id,
        travelClass: state.selectedClass,
        seatNumber: state.selectedSeat,
        paymentMethod: 'Credit Card (Simulated)',
        passenger: {
            firstName: document.getElementById('passFirstName').value.trim(),
            lastName: document.getElementById('passLastName').value.trim(),
            email: document.getElementById('passEmail').value.trim(),
            phone: document.getElementById('passPhone').value.trim(),
            gender: document.getElementById('passGender').value,
            passportOrId: document.getElementById('passPassport').value.trim()
        }
    };

    try {
        const res = await fetch('/api/bookings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await res.json();

        if (data.success && data.booking) {
            closeModal('passengerModal');
            showBoardingPass(data.booking);
        } else {
            throw new Error(data.message || 'Could not complete booking.');
        }
    } catch (err) {
        console.error('Booking submission error:', err);
        alert('Booking Failed: ' + err.message);
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}

// 11. Display Real Electronic Boarding Pass
function showBoardingPass(booking) {
    state.currentBooking = booking;

    const depDate = new Date(booking.departure_time);
    const arrDate = new Date(booking.arrival_time);

    // Compute boarding time (45 mins prior to departure)
    const boardDate = new Date(depDate.getTime() - 45 * 60000);

    const formatTime = (d) => d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const formatDate = (d) => d.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });

    // Populate Main Ticket
    document.getElementById('tktAirline').textContent = booking.airline_name;
    document.getElementById('tktClassBadge').textContent = booking.travel_class.toUpperCase();
    document.getElementById('tktOriginCode').textContent = booking.origin_code;
    document.getElementById('tktOriginCity').textContent = booking.origin_city || booking.origin_code;
    document.getElementById('tktDepTime').textContent = formatTime(depDate);

    document.getElementById('tktDuration').textContent = booking.duration || 'Direct';
    document.getElementById('tktFlightNumber').textContent = booking.flight_number;

    document.getElementById('tktDestCode').textContent = booking.destination_code;
    document.getElementById('tktDestCity').textContent = booking.destination_city || booking.destination_code;
    document.getElementById('tktArrTime').textContent = formatTime(arrDate);

    document.getElementById('tktPassengerName').textContent = `${booking.first_name} ${booking.last_name}`;
    document.getElementById('tktDate').textContent = formatDate(depDate);
    document.getElementById('tktBoardingTime').textContent = formatTime(boardDate);
    document.getElementById('tktGate').textContent = booking.gate || 'G12';
    document.getElementById('tktTerminal').textContent = booking.terminal || 'T2';
    document.getElementById('tktSeat').textContent = booking.seat_number;
    document.getElementById('tktPnr').textContent = booking.pnr;

    // Populate Stub
    document.getElementById('stubFlight').textContent = booking.flight_number;
    document.getElementById('stubPassenger').textContent = `${booking.first_name} ${booking.last_name}`;
    document.getElementById('stubRoute').innerHTML = `${booking.origin_code} &rarr; ${booking.destination_code}`;
    document.getElementById('stubSeat').textContent = booking.seat_number;
    document.getElementById('stubFare').textContent = `$${Number(booking.total_fare).toFixed(2)}`;

    openModal('ticketModal');
}

// 12. Manage Booking (PNR Lookup & Cancel Reservation)
function openManageBookingModal() {
    document.getElementById('pnrResultCard').classList.add('hidden');
    document.getElementById('lookupPnrInput').value = '';
    openModal('manageBookingModal');
}

async function handlePnrLookup(e) {
    e.preventDefault();
    const pnr = document.getElementById('lookupPnrInput').value.trim().toUpperCase();
    if (!pnr) return;

    const btn = document.getElementById('btnLookupPnr');
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Searching...';
    btn.disabled = true;

    try {
        const res = await fetch(`/api/bookings/${pnr}`);
        const data = await res.json();

        if (data.success && data.booking) {
            renderPnrResult(data.booking);
        } else {
            alert(data.message || 'No booking found for this PNR.');
            document.getElementById('pnrResultCard').classList.add('hidden');
        }
    } catch (err) {
        alert('Error retrieving booking: ' + err.message);
    } finally {
        btn.innerHTML = '<i class="fa-solid fa-magnifying-glass"></i> Search Booking';
        btn.disabled = false;
    }
}

function renderPnrResult(booking) {
    state.currentBooking = booking;
    const card = document.getElementById('pnrResultCard');
    card.classList.remove('hidden');

    const statusBadge = document.getElementById('pnrResultStatus');
    statusBadge.textContent = booking.booking_status;
    if (booking.booking_status === 'CANCELLED') {
        statusBadge.className = 'pnr-badge-tag cancelled';
        document.getElementById('btnCancelBooking').style.display = 'none';
    } else {
        statusBadge.className = 'pnr-badge-tag';
        document.getElementById('btnCancelBooking').style.display = 'inline-flex';
    }

    const depDate = new Date(booking.departure_time);
    document.getElementById('pnrResultDate').textContent = `Booked on ${new Date(booking.booking_date).toLocaleDateString()}`;
    document.getElementById('pnrResultPassenger').textContent = `${booking.first_name} ${booking.last_name}`;
    document.getElementById('pnrResultEmail').textContent = booking.email;
    document.getElementById('pnrResultFlight').textContent = `${booking.airline_name} (${booking.flight_number})`;
    document.getElementById('pnrResultRoute').textContent = `${booking.origin_city} (${booking.origin_code}) → ${booking.destination_city} (${booking.destination_code})`;
    document.getElementById('pnrResultTime').textContent = `${depDate.toDateString()} at ${depDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
    document.getElementById('pnrResultSeat').textContent = booking.seat_number;
    document.getElementById('pnrResultClass').textContent = `${booking.travel_class} Class`;
    document.getElementById('pnrResultFare').textContent = `$${Number(booking.total_fare).toFixed(2)} (${booking.payment_status})`;

    document.getElementById('btnViewTicketFromPnr').onclick = () => {
        closeModal('manageBookingModal');
        showBoardingPass(booking);
    };
}

async function handleCancelBooking() {
    if (!state.currentBooking) return;
    const pnr = state.currentBooking.pnr;

    if (!confirm(`Are you sure you want to cancel booking ${pnr}? Your seat will be released and payment marked as REFUNDED.`)) {
        return;
    }

    try {
        const res = await fetch(`/api/bookings/${pnr}/cancel`, { method: 'PUT' });
        const data = await res.json();

        if (data.success) {
            alert(data.message);
            // Re-fetch updated booking
            const updatedRes = await fetch(`/api/bookings/${pnr}`);
            const updatedData = await updatedRes.json();
            if (updatedData.booking) {
                renderPnrResult(updatedData.booking);
            }
        } else {
            alert('Failed to cancel: ' + data.message);
        }
    } catch (err) {
        alert('Error during cancellation: ' + err.message);
    }
}

// 13. Sort Flights Handler
function handleSortFlights() {
    const sortBy = document.getElementById('sortFlightsSelect').value;
    if (!state.searchResults || state.searchResults.length === 0) return;

    const list = [...state.searchResults];

    if (sortBy === 'price-asc') {
        list.sort((a, b) => Number(a.economy_price) - Number(b.economy_price));
    } else if (sortBy === 'time-asc') {
        list.sort((a, b) => new Date(a.departure_time) - new Date(b.departure_time));
    } else if (sortBy === 'duration-asc') {
        list.sort((a, b) => (a.duration || '').localeCompare(b.duration || ''));
    }

    renderFlightCards(list);
}

// Modal Utility Functions
function openModal(id) {
    document.getElementById(id).classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
    document.body.style.overflow = '';
}

// Close modal when clicking outside content
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
        document.body.style.overflow = '';
    }
});
