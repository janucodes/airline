-- =======================================================
-- AIRLINE TICKET BOOKING SYSTEM - DATABASE SCHEMA
-- Compatible with MySQL Workbench & MySQL Server 8.0+
-- =======================================================

DROP DATABASE IF EXISTS airline_db;
CREATE DATABASE airline_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE airline_db;

-- 1. AIRPORTS TABLE
CREATE TABLE airports (
    airport_code VARCHAR(3) PRIMARY KEY,
    city VARCHAR(100) NOT NULL,
    airport_name VARCHAR(150) NOT NULL,
    country VARCHAR(100) NOT NULL
);

-- 2. FLIGHTS TABLE
CREATE TABLE flights (
    flight_id INT AUTO_INCREMENT PRIMARY KEY,
    flight_number VARCHAR(10) NOT NULL,
    airline_name VARCHAR(100) NOT NULL,
    origin_code VARCHAR(3) NOT NULL,
    destination_code VARCHAR(3) NOT NULL,
    departure_time DATETIME NOT NULL,
    arrival_time DATETIME NOT NULL,
    duration VARCHAR(50) NOT NULL,
    economy_price DECIMAL(10, 2) NOT NULL,
    business_price DECIMAL(10, 2) NOT NULL,
    first_class_price DECIMAL(10, 2) NOT NULL,
    aircraft_model VARCHAR(80) NOT NULL,
    gate VARCHAR(10) DEFAULT 'G12',
    terminal VARCHAR(10) DEFAULT 'T2',
    total_seats INT DEFAULT 60,
    FOREIGN KEY (origin_code) REFERENCES airports(airport_code) ON DELETE CASCADE,
    FOREIGN KEY (destination_code) REFERENCES airports(airport_code) ON DELETE CASCADE
);

-- 3. PASSENGERS TABLE
CREATE TABLE passengers (
    passenger_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(60) NOT NULL,
    last_name VARCHAR(60) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(25) NOT NULL,
    gender VARCHAR(15) NOT NULL,
    passport_or_id VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. BOOKINGS TABLE
CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    pnr VARCHAR(10) NOT NULL UNIQUE,
    flight_id INT NOT NULL,
    passenger_id INT NOT NULL,
    travel_class ENUM('Economy', 'Business', 'First Class') NOT NULL,
    seat_number VARCHAR(6) NOT NULL,
    total_fare DECIMAL(10, 2) NOT NULL,
    booking_status ENUM('CONFIRMED', 'CANCELLED') DEFAULT 'CONFIRMED',
    payment_status ENUM('PAID', 'REFUNDED') DEFAULT 'PAID',
    payment_method VARCHAR(50) DEFAULT 'Credit Card (Simulated)',
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (flight_id) REFERENCES flights(flight_id) ON DELETE CASCADE,
    FOREIGN KEY (passenger_id) REFERENCES passengers(passenger_id) ON DELETE CASCADE
);

-- 5. SEATS TABLE (Track occupied seats per flight)
CREATE TABLE seats (
    seat_id INT AUTO_INCREMENT PRIMARY KEY,
    flight_id INT NOT NULL,
    seat_number VARCHAR(6) NOT NULL,
    travel_class ENUM('Economy', 'Business', 'First Class') NOT NULL,
    is_booked BOOLEAN DEFAULT FALSE,
    booking_id INT DEFAULT NULL,
    FOREIGN KEY (flight_id) REFERENCES flights(flight_id) ON DELETE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE SET NULL,
    UNIQUE KEY unique_flight_seat (flight_id, seat_number)
);

-- =======================================================
-- SEED DATA INSERTION
-- =======================================================

-- Insert Airports
INSERT INTO airports (airport_code, city, airport_name, country) VALUES
('JFK', 'New York', 'John F. Kennedy International Airport', 'United States'),
('LAX', 'Los Angeles', 'Los Angeles International Airport', 'United States'),
('LHR', 'London', 'Heathrow Airport', 'United Kingdom'),
('DXB', 'Dubai', 'Dubai International Airport', 'United Arab Emirates'),
('DEL', 'New Delhi', 'Indira Gandhi International Airport', 'India'),
('BOM', 'Mumbai', 'Chhatrapati Shivaji Maharaj International Airport', 'India'),
('BLR', 'Bengaluru', 'Kempegowda International Airport', 'India'),
('SIN', 'Singapore', 'Singapore Changi Airport', 'Singapore'),
('HND', 'Tokyo', 'Haneda Airport', 'Japan'),
('SYD', 'Sydney', 'Sydney Kingsford Smith Airport', 'Australia'),
('CDG', 'Paris', 'Charles de Gaulle Airport', 'France'),
('FRA', 'Frankfurt', 'Frankfurt Airport', 'Germany');

-- Helper Stored Procedure to populate dynamic flights across today and upcoming days
DELIMITER $$
CREATE PROCEDURE PopulateDynamicFlights()
BEGIN
    DECLARE i INT DEFAULT 0;
    WHILE i <= 14 DO
        -- Daily Flights on Major Routes
        -- JFK to LAX
        INSERT INTO flights (flight_number, airline_name, origin_code, destination_code, departure_time, arrival_time, duration, economy_price, business_price, first_class_price, aircraft_model, gate, terminal)
        VALUES 
        ('AA-101', 'American Airways', 'JFK', 'LAX', DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '08:30:00' HOUR_SECOND), DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '11:45:00' HOUR_SECOND), '5h 15m', 249.00, 599.00, 1199.00, 'Boeing 787-9 Dreamliner', 'A14', 'Terminal 8'),
        ('DL-405', 'Delta Airlines', 'JFK', 'LAX', DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '16:00:00' HOUR_SECOND), DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '19:20:00' HOUR_SECOND), '5h 20m', 279.00, 649.00, 1249.00, 'Airbus A350-900', 'B22', 'Terminal 4');

        -- LAX to JFK
        INSERT INTO flights (flight_number, airline_name, origin_code, destination_code, departure_time, arrival_time, duration, economy_price, business_price, first_class_price, aircraft_model, gate, terminal)
        VALUES 
        ('AA-102', 'American Airways', 'LAX', 'JFK', DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '09:00:00' HOUR_SECOND), DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '17:30:00' HOUR_SECOND), '5h 30m', 255.00, 610.00, 1210.00, 'Boeing 787-9 Dreamliner', 'C10', 'Terminal 4');

        -- LHR to DXB
        INSERT INTO flights (flight_number, airline_name, origin_code, destination_code, departure_time, arrival_time, duration, economy_price, business_price, first_class_price, aircraft_model, gate, terminal)
        VALUES 
        ('EK-008', 'Emirates', 'LHR', 'DXB', DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '14:20:00' HOUR_SECOND), DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '23:50:00' HOUR_SECOND), '6h 30m', 520.00, 1450.00, 2890.00, 'Airbus A380-800', 'G18', 'Terminal 3'),
        ('BA-107', 'British Airways', 'LHR', 'DXB', DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '19:15:00' HOUR_SECOND), DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i+1 DAY), INTERVAL '05:40:00' HOUR_SECOND), '7h 25m', 480.00, 1390.00, 2750.00, 'Boeing 777-300ER', 'A12', 'Terminal 5');

        -- DXB to DEL
        INSERT INTO flights (flight_number, airline_name, origin_code, destination_code, departure_time, arrival_time, duration, economy_price, business_price, first_class_price, aircraft_model, gate, terminal)
        VALUES 
        ('EK-512', 'Emirates', 'DXB', 'DEL', DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '04:10:00' HOUR_SECOND), DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '09:05:00' HOUR_SECOND), '3h 25m', 190.00, 480.00, 890.00, 'Boeing 777-200LR', 'F09', 'Terminal 3');

        -- DEL to BOM
        INSERT INTO flights (flight_number, airline_name, origin_code, destination_code, departure_time, arrival_time, duration, economy_price, business_price, first_class_price, aircraft_model, gate, terminal)
        VALUES 
        ('AI-805', 'Air India', 'DEL', 'BOM', DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '07:00:00' HOUR_SECOND), DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '09:15:00' HOUR_SECOND), '2h 15m', 85.00, 210.00, 420.00, 'Airbus A321neo', 'T14', 'Terminal 3'),
        ('6E-204', 'IndiGo', 'DEL', 'BOM', DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '18:45:00' HOUR_SECOND), DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '21:00:00' HOUR_SECOND), '2h 15m', 75.00, 180.00, 360.00, 'Airbus A320neo', 'T08', 'Terminal 1');

        -- BOM to BLR
        INSERT INTO flights (flight_number, airline_name, origin_code, destination_code, departure_time, arrival_time, duration, economy_price, business_price, first_class_price, aircraft_model, gate, terminal)
        VALUES 
        ('AI-602', 'Air India', 'BOM', 'BLR', DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '11:10:00' HOUR_SECOND), DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '13:00:00' HOUR_SECOND), '1h 50m', 65.00, 160.00, 310.00, 'Airbus A320neo', 'B04', 'Terminal 2');

        -- SIN to HND
        INSERT INTO flights (flight_number, airline_name, origin_code, destination_code, departure_time, arrival_time, duration, economy_price, business_price, first_class_price, aircraft_model, gate, terminal)
        VALUES 
        ('SQ-638', 'Singapore Airlines', 'SIN', 'HND', DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '23:55:00' HOUR_SECOND), DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i+1 DAY), INTERVAL '07:30:00' HOUR_SECOND), '6h 35m', 410.00, 1150.00, 2400.00, 'Boeing 787-10', 'E05', 'Terminal 3');

        -- CDG to JFK
        INSERT INTO flights (flight_number, airline_name, origin_code, destination_code, departure_time, arrival_time, duration, economy_price, business_price, first_class_price, aircraft_model, gate, terminal)
        VALUES 
        ('AF-006', 'Air France', 'CDG', 'JFK', DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '13:50:00' HOUR_SECOND), DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '16:15:00' HOUR_SECOND), '8h 25m', 590.00, 1620.00, 3200.00, 'Boeing 777-300ER', 'K43', 'Terminal 2E');

        -- FRA to SIN
        INSERT INTO flights (flight_number, airline_name, origin_code, destination_code, departure_time, arrival_time, duration, economy_price, business_price, first_class_price, aircraft_model, gate, terminal)
        VALUES 
        ('LH-778', 'Lufthansa', 'FRA', 'SIN', DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i DAY), INTERVAL '21:55:00' HOUR_SECOND), DATE_ADD(DATE_ADD(CURDATE(), INTERVAL i+1 DAY), INTERVAL '16:15:00' HOUR_SECOND), '12h 20m', 680.00, 1890.00, 3600.00, 'Airbus A340-300', 'Z69', 'Terminal 1');

        SET i = i + 1;
    END WHILE;
END$$
DELIMITER ;

CALL PopulateDynamicFlights();
DROP PROCEDURE PopulateDynamicFlights;

-- Insert a Demo Passenger
INSERT INTO passengers (first_name, last_name, email, phone, gender, passport_or_id) VALUES
('John', 'Anderson', 'john.anderson@example.com', '+1-555-0199', 'Male', 'US987654321');

-- Insert a Demo Booking with reference PNR 'SKY-7821'
INSERT INTO bookings (pnr, flight_id, passenger_id, travel_class, seat_number, total_fare, booking_status, payment_status, payment_method)
VALUES ('SKY-7821', 1, 1, 'Business', '02B', 599.00, 'CONFIRMED', 'PAID', 'Visa ending in 4242');

-- Seed sample occupied seat for the first flight
INSERT INTO seats (flight_id, seat_number, travel_class, is_booked, booking_id) VALUES
(1, '02B', 'Business', TRUE, 1),
(1, '05A', 'Economy', TRUE, NULL),
(1, '05B', 'Economy', TRUE, NULL),
(1, '10F', 'Economy', TRUE, NULL);

-- Verification Query to check data is loaded properly
SELECT 
    b.pnr,
    CONCAT(p.first_name, ' ', p.last_name) AS passenger_name,
    f.flight_number,
    f.airline_name,
    f.origin_code,
    f.destination_code,
    b.travel_class,
    b.seat_number,
    b.total_fare,
    b.booking_status
FROM bookings b
JOIN passengers p ON b.passenger_id = p.passenger_id
JOIN flights f ON b.flight_id = f.flight_id;
