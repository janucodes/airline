@echo off
title AeroJet Airlines - Ticket Booking System
echo ========================================================
echo Starting AeroJet Airlines Server...
echo ========================================================
echo.
npm start
pause
